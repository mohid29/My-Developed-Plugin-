<!-- Apply Now Popup -->
<div id="apply-popup" class="popup-form">
    <div class="form-content">
        <button class="close-btn" onclick="closeApplyForm()">&#10005;</button>
        <h3>Apply for <span id="job-title"></span></h3>
        <form id="apply-form">
            <input type="text" id="candidate-name" placeholder="Name" required>
            <input type="email" id="candidate-email" placeholder="Email" required>
            <input type="tel" id="candidate-phone" placeholder="Phone" required>
            <input type="text" id="candidate-address" placeholder="Address" required>
            <input type="text" id="candidate-city" placeholder="City" required>
            <input type="text" id="candidate-experience" placeholder="Experience in Last Job" required>
            <textarea id="candidate-cover-letter" placeholder="Cover Letter" rows="4" required></textarea>
            <button type="button" onclick="submitApplication()">Submit Application</button>
        </form>
    </div>
</div>


<!-- View Details Popup -->
<div id="details-popup" class="popup-form">
    <div class="form-content">
        <button class="close-btn" onclick="closeDetails()">&#10005;</button>
        <h3>Job Details for <span id="details-job-title"></span></h3>
        <p><strong>Salary:</strong> <span id="details-salary"></span></p>
        <p><strong>Location:</strong> <span id="details-location"></span></p>
        <p id="details-content"></p>
    </div>
</div>

