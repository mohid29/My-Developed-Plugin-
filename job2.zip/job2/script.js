function openDetails(jobTitle, salary, location, jobContent) {
    const detailsPopup = document.getElementById('details-popup');
    document.getElementById('details-job-title').innerText = jobTitle;
    document.getElementById('details-salary').innerText = salary;
    document.getElementById('details-location').innerText = location;
    document.getElementById('details-content').innerText = jobContent;
    detailsPopup.style.display = 'flex';
}

function closeDetails() {
    document.getElementById('details-popup').style.display = 'none';
}

function openApplyForm(jobTitle) {
    document.getElementById('apply-popup').style.display = 'flex';
    document.getElementById('job-title').innerText = jobTitle;
}

function closeApplyForm() {
    document.getElementById('apply-popup').style.display = 'none';
}

function submitApplication() {
    const name = document.getElementById('candidate-name').value;
    const email = document.getElementById('candidate-email').value;
    const phone = document.getElementById('candidate-phone').value;
    const address = document.getElementById('candidate-address').value;
    const city = document.getElementById('candidate-city').value;
    const experience = document.getElementById('candidate-experience').value;
    const coverLetter = document.getElementById('candidate-cover-letter').value;
    const jobTitle = document.getElementById('job-title').innerText;

    const message = `New application for ${jobTitle}:\n\nName: ${name}\nEmail: ${email}\nPhone: ${phone}\nAddress: ${address}\nCity: ${city}\nExperience: ${experience}\nCover Letter: ${coverLetter}`;
    
    window.open(`https://api.whatsapp.com/send?phone=YOUR_PHONE_NUMBER&text=${encodeURIComponent(message)}`, '_blank');
    closeApplyForm();
}


// Enqueue Styles and Scripts
function job_cards_enqueue_scripts() {
    wp_enqueue_style('job-cards-style', plugins_url('/style.css', __FILE__));
    wp_enqueue_script('job-cards-script', plugins_url('/script.js', __FILE__), array('jquery'), null, true);
}
add_action('wp_enqueue_scripts', 'job_cards_enqueue_scripts');
