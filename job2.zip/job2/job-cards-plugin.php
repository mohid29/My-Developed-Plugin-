<?php
/*
Plugin Name: Job Cards Plugin
Description: A plugin to display job cards with images and apply button with form  submit button to your whatsapp number and view details show the job in a popup form .
Version: 1.0
Author: Mohid Naz
*/

// Enqueue Styles and Scripts
function job_cards_enqueue_scripts() {
    wp_enqueue_style('job-cards-style', plugins_url('/style.css', __FILE__));
    wp_enqueue_script('job-cards-script', plugins_url('/script.js', __FILE__), array('jquery'), null, true);
}
add_action('wp_enqueue_scripts', 'job_cards_enqueue_scripts');

// Register Custom Post Type for Job Cards
function job_cards_custom_post_type() {
    $labels = array(
        'name'                  => _x('Job Cards', 'Post Type General Name', 'text_domain'),
        'singular_name'         => _x('Job Card', 'Post Type Singular Name', 'text_domain'),
        'menu_name'             => __('Job Cards', 'text_domain'),
        'name_admin_bar'        => __('Job Card', 'text_domain'),
        'archives'              => __('Item Archives', 'text_domain'),
        'attributes'            => __('Item Attributes', 'text_domain'),
        'parent_item_colon'     => __('Parent Item:', 'text_domain'),
        'all_items'             => __('All Items', 'text_domain'),
        'add_new_item'          => __('Add New Item', 'text_domain'),
        'add_new'               => __('Add New', 'text_domain'),
        'new_item'              => __('New Item', 'text_domain'),
        'edit_item'             => __('Edit Item', 'text_domain'),
        'update_item'           => __('Update Item', 'text_domain'),
        'view_item'             => __('View Item', 'text_domain'),
        'view_items'            => __('View Items', 'text_domain'),
        'search_items'          => __('Search Item', 'text_domain'),
        'not_found'             => __('Not found', 'text_domain'),
        'not_found_in_trash'    => __('Not found in Trash', 'text_domain'),
        'featured_image'        => __('Featured Image', 'text_domain'),
        'set_featured_image'    => __('Set featured image', 'text_domain'),
        'remove_featured_image' => __('Remove featured image', 'text_domain'),
        'use_featured_image'    => __('Use as featured image', 'text_domain'),
        'insert_into_item'      => __('Insert into item', 'text_domain'),
        'uploaded_to_this_item' => __('Uploaded to this item', 'text_domain'),
        'items_list'            => __('Items list', 'text_domain'),
        'items_list_navigation' => __('Items list navigation', 'text_domain'),
        'filter_items_list'     => __('Filter items list', 'text_domain'),
    );
    $args = array(
        'label'                 => __('Job Card', 'text_domain'),
        'description'           => __('Custom Post Type for Job Cards', 'text_domain'),
        'labels'                => $labels,
        'supports'              => array('title', 'editor', 'thumbnail'),
        'taxonomies'            => array(),
        'hierarchical'          => false,
        'public'                => true,
        'show_ui'               => true,
        'show_in_menu'          => true,
        'show_in_admin_bar'     => true,
        'show_in_nav_menus'     => true,
        'can_export'            => true,
        'has_archive'           => true,
        'exclude_from_search'   => false,
        'publicly_queryable'    => true,
        'capability_type'       => 'post',
    );
    register_post_type('job_card', $args);
}
add_action('init', 'job_cards_custom_post_type', 0);

// Shortcode for Job Cards
function job_cards_shortcode() {
    ob_start();

    $args = array(
        'post_type' => 'job_card',
        'posts_per_page' => -1
    );

    $query = new WP_Query($args);

    if ($query->have_posts()) {
        echo '<div class="job-cards">';
        while ($query->have_posts()) {
            $query->the_post();
            $job_title = get_the_title();
            $job_content = get_the_content();
            $job_image = get_the_post_thumbnail_url(get_the_ID(), 'medium');

            echo '<div class="job-card">';
            echo '<div class="job-info">';
            echo "<h3>{$job_title}</h3>";
            echo '<p>' . get_post_meta(get_the_ID(), 'location', true) . '</p>';
            echo '<p>' . get_post_meta(get_the_ID(), 'salary', true) . '</p>';
            echo '<button class="apply-btn" onclick="openApplyForm(\'' . esc_js($job_title) . '\')">Apply Now</button>';
            echo '<button class="details-btn" onclick="openDetails(\'' . esc_js($job_title) . '\', \'' . esc_js(get_post_meta(get_the_ID(), 'salary', true)) . '\', \'' . esc_js(get_post_meta(get_the_ID(), 'location', true)) . '\', \'' . esc_js($job_content) . '\')">View Details</button>';
            echo '</div>';
            echo '<img src="' . esc_url($job_image) . '" alt="Job Image">';
            echo '</div>';
        }
        echo '</div>';
    } else {
        echo 'No job cards found.';
    }
    wp_reset_postdata();

    // Include popup HTML
    include 'popup-html.php';

    return ob_get_clean();
}
add_shortcode('job_cards', 'job_cards_shortcode');


// Add custom meta boxes
function job_cards_add_meta_boxes() {
    add_meta_box('job_card_details', 'Job Card Details', 'job_cards_meta_box_callback', 'job_card', 'normal', 'high');
}
add_action('add_meta_boxes', 'job_cards_add_meta_boxes');

function job_cards_meta_box_callback($post) {
    wp_nonce_field('job_cards_save_meta_box_data', 'job_cards_meta_box_nonce');

    $location = get_post_meta($post->ID, 'location', true);
    $salary = get_post_meta($post->ID, 'salary', true);

    echo '<p><label for="job_location">Location: </label>';
    echo '<input type="text" id="job_location" name="job_location" value="' . esc_attr($location) . '" size="25" /></p>';

    echo '<p><label for="job_salary">Salary: </label>';
    echo '<input type="text" id="job_salary" name="job_salary" value="' . esc_attr($salary) . '" size="25" /></p>';
}

// Save custom meta box data
function job_cards_save_meta_box_data($post_id) {
    if (!isset($_POST['job_cards_meta_box_nonce'])) {
        return;
    }
    if (!wp_verify_nonce($_POST['job_cards_meta_box_nonce'], 'job_cards_save_meta_box_data')) {
        return;
    }
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return;
    }
    if (!current_user_can('edit_post', $post_id)) {
        return;
    }

    if (isset($_POST['job_location'])) {
        update_post_meta($post_id, 'location', sanitize_text_field($_POST['job_location']));
    }
    if (isset($_POST['job_salary'])) {
        update_post_meta($post_id, 'salary', sanitize_text_field($_POST['job_salary']));
    }
}
add_action('save_post', 'job_cards_save_meta_box_data');
